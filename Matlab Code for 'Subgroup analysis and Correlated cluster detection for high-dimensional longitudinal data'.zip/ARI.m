function ARI=ARI(a,b)
m=length(a);
n=length(b);
aa=unique(a);
bb=unique(b);
m1=length(aa);
n1=length(bb);
S=zeros(m1+1,n1+1);
for i=1:1:m1
    for j=1:1:n1
        LL=find(a==aa(i));
        SS=find(b==bb(j));
        S(i,j)=length(intersect(LL,SS));
    end
end
S(m1+1,:)=sum(S(1:m1,:),1);
S(:,n1+1)=sum(S(:,1:n1),2);

u=0;
u1=0;
u2=0;
for i=1:1:m1
    for j=1:1:n1
        
        
        
        
        if S(i,j)>=2
            u=S(i,j)*(S(i,j)-1)/2+u;
        end
        
        
    end
end

for i=1:1:m1
    if S(i,n1+1)>=2
        u1=u1+S(i,n1+1)*(S(i,n1+1)-1)/2;
    end
    
end

for j=1:1:n1
    if S(m1+1,j)>=2
        u2=u2+S(m1+1,j)*(S(m1+1,j)-1)/2;
    end
end
ARI=(u-u1*u2/(n*(n-1)/2))/((u1+u2)/2-u1*u2/(n*(n-1)/2));
end